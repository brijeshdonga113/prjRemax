﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace prjRemax_2013355
{
    public partial class frmHouse : Form
    {
        public frmHouse()
        {
            InitializeComponent();
        }
        DataTable tabHouse, tabAgent, tabClient;
        int currentIndex;
        string mode;

        private void btnFirst_Click(object sender, EventArgs e)
        {
            currentIndex = 0;
            Display();
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            if (currentIndex > 0)
            {
                currentIndex--;
                Display();
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (currentIndex < (tabHouse.Rows.Count - 1))
            {
                currentIndex++;
                Display();
            }
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            currentIndex = (tabHouse.Rows.Count - 1);
            Display();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            mode = "add";
            txtType.Text = txtLocation.Text = txtPrix.Text = txtDescription.Text ="";
            cboAgent.Text = cboNbrBathroom.Text =cboNbrChambre.Text ="";
            txtType.Focus();
        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            mode = "edit";
            txtType.Focus();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            DataRow currentRow = (mode == "add") ? tabHouse.NewRow() : tabHouse.Rows[currentIndex];
            currentRow["hType"] = txtType.Text;
            currentRow["hLocation"] = txtLocation.Text;
            currentRow["hPrice"] = Convert.ToInt32(txtPrix.Text);
            currentRow["hNoOfRooms"] = cboNbrChambre.SelectedItem.ToString();
            currentRow["hNoOfBath"] = cboNbrBathroom.SelectedItem.ToString();
            currentRow["hDec"] = txtDescription.Text;
            foreach (DataRow myrow in tabAgent.Rows)
            {
                if (myrow["aName"].ToString() == cboAgent.SelectedItem.ToString())
                {
                    currentRow["agentNumber"] = Convert.ToInt32(myrow["agentId"]);
                }
            }
            if (mode == "add") { tabHouse.Rows.Add(currentRow); }

            SqlCommandBuilder myBuilder = new SqlCommandBuilder(clsGlobal.adpHouse);
            clsGlobal.adpHouse.Update(clsGlobal.mySet, "House");
            clsGlobal.mySet.Tables.Remove("House");
            clsGlobal.adpHouse.Fill(clsGlobal.mySet, "House");

            tabHouse = clsGlobal.mySet.Tables["House"];

            if (mode == "add") { currentIndex = tabHouse.Rows.Count - 1; }

            mode = "";
            Display();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string mes = "Are you sure to delete this House ?";
            string title = "House Deletion Warning";
            if (MessageBox.Show(mes, title, MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                tabHouse.Rows[currentIndex].Delete();
                SqlCommandBuilder myBuilder = new SqlCommandBuilder(clsGlobal.adpHouse);
                clsGlobal.adpHouse.Update(clsGlobal.mySet, "House");
                clsGlobal.mySet.Tables.Remove("House");
                clsGlobal.adpHouse.Fill(clsGlobal.mySet, "House");

                tabHouse = clsGlobal.mySet.Tables["House"];
                currentIndex = 0;
                Display();
            }
        }

        private void frmHouse_Load(object sender, EventArgs e)
        {
            tabClient = clsGlobal.mySet.Tables["Client"];
            tabAgent = clsGlobal.mySet.Tables["Agent"];
            tabHouse = clsGlobal.mySet.Tables["House"];

            foreach (DataRow myRow in tabAgent.Rows)
            {
                cboAgent.Items.Add(myRow["aName"]);
            }

            //DataColumn[] mycol = new DataColumn[1];
            //mycol[0] = tabHouse.Columns["hId"];
            //mycol[0].AutoIncrement = true;
            //mycol[0].AutoIncrementSeed = 1;
            //tabHouse.PrimaryKey = mycol;

            dataHouse.DataSource = tabHouse.AsDataView();
            currentIndex = 0;
            Display();
        }

        private void Display()
        {
            txtType.Text = tabHouse.Rows[currentIndex]["hType"].ToString();
            txtLocation.Text = tabHouse.Rows[currentIndex]["hLocation"].ToString();
            txtDescription.Text = tabHouse.Rows[currentIndex]["hDec"].ToString();
            txtPrix.Text = tabHouse.Rows[currentIndex]["hPrice"].ToString();
            cboNbrChambre.Text = tabHouse.Rows[currentIndex]["hNoOfRooms"].ToString();
            cboNbrBathroom.Text = tabHouse.Rows[currentIndex]["hNoOfBath"].ToString();
            
            foreach (DataRow myRow in tabAgent.Rows)
            {
                if (myRow["agentId"] == tabHouse.Rows[currentIndex]["agentNumber"])
                {
                    cboAgent.Text = myRow["aName"].ToString();
                }
            }

            dataHouse.DataSource = tabHouse.AsDataView();
        }
    }
}

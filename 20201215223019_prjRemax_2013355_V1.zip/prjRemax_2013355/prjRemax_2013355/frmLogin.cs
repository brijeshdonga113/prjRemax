﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace prjRemax_2013355
{
    public partial class frmLogin : Form
    {
        DataTable tabAdmin, tabClient, tabAgent;

        private void btnSignIn_Click(object sender, EventArgs e)
        {
            tabAdmin = clsGlobal.mySet.Tables["Admin"];
            tabAgent = clsGlobal.mySet.Tables["Agent"];
            tabClient = clsGlobal.mySet.Tables["Client"];

            if (comboBox1.SelectedItem.ToString() == "Admin")
            {
                var admins = from admin in tabAdmin.AsEnumerable()
                             where admin.Field<string>("adminUsername") == txtEmail.Text.ToString() && admin.Field<string>("adminPassword") == txtPassword.Text.ToString()
                             select admin;

                if (admins.Count() > 0)
                {
                    clsGlobal.log_in_Status = "admin";
                    this.Hide();
                    frmMain fa = new frmMain();
                    fa.Show();

                }
                else
                {
                    MessageBox.Show("Wrong Username or Password");
                }

            }else if (comboBox1.SelectedItem.ToString() == "Agent")
            {
                var agents = from agent in tabAgent.AsEnumerable()
                             where agent.Field<string>("aUsername") == txtEmail.Text.ToString() && agent.Field<string>("aPassword") == txtPassword.Text.ToString()
                             select agent;

                if (agents.Count() > 0)
                {
                    clsGlobal.log_in_Status = "agent";
                    this.Hide();
                    frmMain fa = new frmMain();
                    fa.Show();
                }
                else
                {
                    MessageBox.Show("Wrong Username or Password");
                }

            }
            else {
                MessageBox.Show("Plese select Item in the combo box");
            }
        }

        private void btnClient_Click(object sender, EventArgs e)
        {
            clsGlobal.log_in_Status = "client";
            this.Hide();
            frmMain fa = new frmMain();
            fa.Show();
        }

        private void frmLogin_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        public frmLogin()
        {
            InitializeComponent();
        }




        private void frmLogin_Load(object sender, EventArgs e)
        {
            clsGlobal.mySet = new DataSet();
            clsGlobal.myCon = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=dbRamex;Integrated Security=True");

            SqlCommand mycmd = new SqlCommand("SELECT * FROM Admin", clsGlobal.myCon);
            clsGlobal.adpAdmin = new SqlDataAdapter(mycmd);
            clsGlobal.adpAdmin.Fill(clsGlobal.mySet, "Admin");

            mycmd = new SqlCommand("SELECT * FROM Agent", clsGlobal.myCon);
            clsGlobal.adpAgent = new SqlDataAdapter(mycmd);
            clsGlobal.adpAgent.Fill(clsGlobal.mySet, "Agent");

            mycmd = new SqlCommand("SELECT * FROM Client", clsGlobal.myCon);
            clsGlobal.adpClient = new SqlDataAdapter(mycmd);
            clsGlobal.adpClient.Fill(clsGlobal.mySet, "Client");

            mycmd = new SqlCommand("SELECT * FROM House", clsGlobal.myCon);
            clsGlobal.adpHouse = new SqlDataAdapter(mycmd);
            clsGlobal.adpHouse.Fill(clsGlobal.mySet, "House");

            DataTable tabhouse = clsGlobal.mySet.Tables["House"];

            lblHouse.Text = $"In ramex we have {tabhouse.Rows.Count} house Registered.";
            //lblMainline.Text = $"In ramex we have {tabAgent.Rows.Count} to handel the {tabClient.Rows.Count} .";
            lblMainline.Text = "----------------- WELCOME TO RAMEX -----------------";

            var house = from ho in tabhouse.AsEnumerable()
                        select new
                        {
                            location = ho.Field<string>("hLocation"),
                            price = ho.Field<decimal>("hPrice")
                        };

            if (house.Count() > 0) {
                dataHosue.DataSource = house.ToList();
            }
        }
    }
}

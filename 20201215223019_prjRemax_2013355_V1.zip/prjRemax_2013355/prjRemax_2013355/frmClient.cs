﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace prjRemax_2013355
{
    public partial class frmClient : Form
    {
        public frmClient()
        {
            InitializeComponent();
        }
        DataTable tabAdmin, tabAgent, tabClient;
        int currentIndex;
        string mode;

        private void btnFirst_Click(object sender, EventArgs e)
        {
            currentIndex = 0;
            Display();
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            if (currentIndex > 0)
            {
                currentIndex--;
                Display();
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (currentIndex < (tabClient.Rows.Count - 1))
            {
                currentIndex++;
                Display();
            }
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            currentIndex = (tabClient.Rows.Count - 1);
            Display();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            mode = "add";
            txtNom.Text = txtEmail.Text = txtPhone.Text = "";
            cboAgent.Text = cboType.Text = "";
            txtNom.Focus();
        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            mode = "edit";
            txtNom.Focus();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            DataRow currentRow = (mode == "add") ? tabClient.NewRow() : tabClient.Rows[currentIndex];
            currentRow["cName"] = txtNom.Text;
            currentRow["cEmail"] = txtEmail.Text;
            currentRow["cType"] = cboType.SelectedItem.ToString();
            currentRow["cPhone"] = txtPhone.Text;
            foreach (DataRow myrow in tabAgent.Rows) {
                if (myrow["aName"].ToString() == cboAgent.SelectedItem.ToString()) {
                    currentRow["agentNumber"] = Convert.ToInt32(myrow["agentId"]);
                }
            }
            if (mode == "add") { tabClient.Rows.Add(currentRow); }

            SqlCommandBuilder myBuilder = new SqlCommandBuilder(clsGlobal.adpClient);
            clsGlobal.adpClient.Update(clsGlobal.mySet, "Client");
            clsGlobal.mySet.Tables.Remove("Client");
            clsGlobal.adpClient.Fill(clsGlobal.mySet, "Client");

            tabClient = clsGlobal.mySet.Tables["Client"];

            if (mode == "add") { currentIndex = tabClient.Rows.Count - 1; }

            mode = "";
            Display();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string mes = "Are you sure to delete this Client ?";
            string title = "Client Deletion Warning";
            if (MessageBox.Show(mes, title, MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                tabClient.Rows[currentIndex].Delete();
                SqlCommandBuilder myBuilder = new SqlCommandBuilder(clsGlobal.adpClient);
                clsGlobal.adpClient.Update(clsGlobal.mySet, "Client");
                clsGlobal.mySet.Tables.Remove("Client");
                clsGlobal.adpClient.Fill(clsGlobal.mySet, "Client");

                tabClient = clsGlobal.mySet.Tables["Client"];

                currentIndex = 0;
                Display();
            }
        }

        private void frmClient_Load(object sender, EventArgs e)
        {
            tabClient = clsGlobal.mySet.Tables["Client"];
            tabAgent = clsGlobal.mySet.Tables["Agent"];

            foreach (DataRow myRow in tabAgent.Rows) {
                cboAgent.Items.Add(myRow["aName"]);
            }

            dataClient.DataSource = tabClient.AsDataView();
            currentIndex = 0;
            Display();

        }

        private void Display()
        {
            txtNom.Text = tabClient.Rows[currentIndex]["cName"].ToString();
            txtEmail.Text = tabClient.Rows[currentIndex]["cEmail"].ToString();
            txtPhone.Text = tabClient.Rows[currentIndex]["cPhone"].ToString();
            cboType.Text = tabClient.Rows[currentIndex]["cType"].ToString();

            foreach (DataRow myRow in tabAgent.Rows)
            {
                if (myRow["agentId"] == tabClient.Rows[currentIndex]["agentNumber"]) {
                    cboAgent.Text = myRow["aName"].ToString();
                }
            }

            dataClient.DataSource = tabClient.AsDataView();
        }
    }
}

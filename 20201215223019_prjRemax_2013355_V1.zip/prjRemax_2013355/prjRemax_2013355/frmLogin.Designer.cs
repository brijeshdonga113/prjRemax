﻿
namespace prjRemax_2013355
{
    partial class frmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.btnSignIn = new System.Windows.Forms.Button();
            this.grpboxLogin = new System.Windows.Forms.GroupBox();
            this.btnClient = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataHosue = new System.Windows.Forms.DataGridView();
            this.lblHouse = new System.Windows.Forms.Label();
            this.lblMainline = new System.Windows.Forms.Label();
            this.grpboxLogin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataHosue)).BeginInit();
            this.SuspendLayout();
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(240, 169);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtEmail.Multiline = true;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(331, 39);
            this.txtEmail.TabIndex = 1;
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(240, 228);
            this.txtPassword.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtPassword.Multiline = true;
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(331, 39);
            this.txtPassword.TabIndex = 2;
            // 
            // btnSignIn
            // 
            this.btnSignIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSignIn.Location = new System.Drawing.Point(384, 315);
            this.btnSignIn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSignIn.Name = "btnSignIn";
            this.btnSignIn.Size = new System.Drawing.Size(189, 56);
            this.btnSignIn.TabIndex = 0;
            this.btnSignIn.Text = "Sign-In";
            this.btnSignIn.UseVisualStyleBackColor = true;
            this.btnSignIn.Click += new System.EventHandler(this.btnSignIn_Click);
            // 
            // grpboxLogin
            // 
            this.grpboxLogin.Controls.Add(this.btnClient);
            this.grpboxLogin.Controls.Add(this.comboBox1);
            this.grpboxLogin.Controls.Add(this.label4);
            this.grpboxLogin.Controls.Add(this.label3);
            this.grpboxLogin.Controls.Add(this.label2);
            this.grpboxLogin.Controls.Add(this.txtEmail);
            this.grpboxLogin.Controls.Add(this.txtPassword);
            this.grpboxLogin.Controls.Add(this.btnSignIn);
            this.grpboxLogin.Location = new System.Drawing.Point(171, 187);
            this.grpboxLogin.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.grpboxLogin.Name = "grpboxLogin";
            this.grpboxLogin.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.grpboxLogin.Size = new System.Drawing.Size(659, 517);
            this.grpboxLogin.TabIndex = 10;
            this.grpboxLogin.TabStop = false;
            this.grpboxLogin.Text = "Login";
            // 
            // btnClient
            // 
            this.btnClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClient.Location = new System.Drawing.Point(84, 396);
            this.btnClient.Name = "btnClient";
            this.btnClient.Size = new System.Drawing.Size(489, 62);
            this.btnClient.TabIndex = 9;
            this.btnClient.Text = "For Client Click here";
            this.btnClient.UseVisualStyleBackColor = true;
            this.btnClient.Click += new System.EventHandler(this.btnClient_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Admin",
            "Agent"});
            this.comboBox1.Location = new System.Drawing.Point(240, 87);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(333, 33);
            this.comboBox1.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(79, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 25);
            this.label4.TabIndex = 7;
            this.label4.Text = "Type:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(79, 228);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(142, 29);
            this.label3.TabIndex = 6;
            this.label3.Text = "Password :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(79, 169);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 29);
            this.label2.TabIndex = 5;
            this.label2.Text = "Email :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(164, 115);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(179, 37);
            this.label1.TabIndex = 11;
            this.label1.Text = "Sign-in as ";
            // 
            // dataHosue
            // 
            this.dataHosue.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataHosue.Location = new System.Drawing.Point(868, 249);
            this.dataHosue.Name = "dataHosue";
            this.dataHosue.RowHeadersWidth = 82;
            this.dataHosue.RowTemplate.Height = 33;
            this.dataHosue.Size = new System.Drawing.Size(564, 455);
            this.dataHosue.TabIndex = 12;
            // 
            // lblHouse
            // 
            this.lblHouse.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lblHouse.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblHouse.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHouse.Location = new System.Drawing.Point(868, 197);
            this.lblHouse.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblHouse.Name = "lblHouse";
            this.lblHouse.Size = new System.Drawing.Size(564, 39);
            this.lblHouse.TabIndex = 22;
            this.lblHouse.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMainline
            // 
            this.lblMainline.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lblMainline.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMainline.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMainline.Location = new System.Drawing.Point(171, 718);
            this.lblMainline.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblMainline.Name = "lblMainline";
            this.lblMainline.Size = new System.Drawing.Size(1261, 79);
            this.lblMainline.TabIndex = 23;
            this.lblMainline.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1477, 955);
            this.Controls.Add(this.lblMainline);
            this.Controls.Add(this.lblHouse);
            this.Controls.Add(this.dataHosue);
            this.Controls.Add(this.grpboxLogin);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmLogin";
            this.Text = "frmLogin";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmLogin_FormClosed);
            this.Load += new System.EventHandler(this.frmLogin_Load);
            this.grpboxLogin.ResumeLayout(false);
            this.grpboxLogin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataHosue)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Button btnSignIn;
        private System.Windows.Forms.GroupBox grpboxLogin;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnClient;
        private System.Windows.Forms.DataGridView dataHosue;
        private System.Windows.Forms.Label lblHouse;
        private System.Windows.Forms.Label lblMainline;
    }
}
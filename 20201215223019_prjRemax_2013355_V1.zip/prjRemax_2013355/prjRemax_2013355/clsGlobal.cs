﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace prjRemax_2013355
{
    public static class clsGlobal
    {
        public static SqlConnection myCon;
        public static SqlDataAdapter adpAdmin, adpAgent, adpClient, adpHouse;
        public static DataSet mySet;
        public static string log_in_Status = "";
    }
}

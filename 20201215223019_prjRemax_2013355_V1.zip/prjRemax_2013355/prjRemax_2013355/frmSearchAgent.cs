﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjRemax_2013355
{
    public partial class frmSearchAgent : Form
    {
        public frmSearchAgent()
        {
            InitializeComponent();
        }
        DataTable tabAdmin, tabAgent, tabClient;
        

        private void btnSearch_Click(object sender, EventArgs e)
        {
            foreach (DataRow myrow in tabAgent.Rows) {
                if (myrow["aName"].ToString() == comAgent.SelectedItem.ToString())
                {
                    var client = from c in tabClient.AsEnumerable()
                                 where c.Field<int>("agentNumber") == Convert.ToInt32(myrow["agentId"])
                                 select c;

                    if (client.Count() > 0) {
                        DataClient.DataSource = client.CopyToDataTable();
                    }
                    else
                    {
                        MessageBox.Show($"Dont have any client for this {myrow["aName"]}");
                    }
                    
                }
            }
        }

        private void frmSearchAgent_Load(object sender, EventArgs e)
        {
            tabClient = clsGlobal.mySet.Tables["Client"];
            tabAgent = clsGlobal.mySet.Tables["Agent"];

            foreach (DataRow myrow in tabAgent.Rows) {
                comAgent.Items.Add(myrow["aName"]);
            }

        }
    }
}

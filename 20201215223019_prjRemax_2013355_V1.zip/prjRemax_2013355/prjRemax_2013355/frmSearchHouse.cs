﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjRemax_2013355
{
    public partial class frmSearchHouse : Form
    {
        public frmSearchHouse()
        {
            InitializeComponent();
        }
        DataTable tabHouse, tabAgent, tabClient;

        private void button1_Click(object sender, EventArgs e)
        {
            dataHouse.DataSource = tabHouse.AsDataView();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            foreach (DataRow myrow in tabAgent.Rows)
            {
                if (myrow["aName"].ToString() == comClient.SelectedItem.ToString())
                {
                    var house = from h in tabHouse.AsEnumerable()
                                 where h.Field<int>("agentNumber") == Convert.ToInt32(myrow["agentId"])
                                 select h;

                    if (house.Count() > 0)
                    {
                        dataHouse.DataSource = house.CopyToDataTable();
                    }
                    else
                    {
                        MessageBox.Show($"Dont have any House for this {myrow["aName"]}");
                    }

                }
            }
        }

        private void frmSearchHouse_Load(object sender, EventArgs e)
        {
            tabClient = clsGlobal.mySet.Tables["Client"];
            tabAgent = clsGlobal.mySet.Tables["Agent"];
            tabHouse = clsGlobal.mySet.Tables["House"];

            foreach (DataRow myrow in tabAgent.Rows)
            {
                comClient.Items.Add(myrow["aName"]);
            }

        }
    }
}
